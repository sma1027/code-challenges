require 'pry'

require_relative '../lib/board.rb'
require_relative '../lib/human.rb'
require_relative '../lib/computer.rb'
require_relative '../lib/game.rb'